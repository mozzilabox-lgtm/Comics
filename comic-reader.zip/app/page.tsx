import { redirect } from "next/navigation"

// The reader is a single self-contained HTML file: public/comic-reader.html
export default function Page() {
  redirect("/comic-reader.html")
}
